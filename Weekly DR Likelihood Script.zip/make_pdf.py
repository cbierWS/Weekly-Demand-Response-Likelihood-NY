"""
NYC Demand Response Weekly Forecast — PDF Generator
Runs every Monday, dynamically builds Mon–Sun dates for the current week,
fetches weather from the National Weather Service API (api.weather.gov),
then POSTs a notification to a Zapier Catch Hook for delivery to Microsoft Teams.

Weather source: NWS (weather.gov) — the same data underlying Weather.com,
completely free, no API key required, authoritative US government source.

Environment variables (set as GitHub Actions secrets):
  ZAPIER_WEBHOOK_URL  — the webhook URL from your Zapier Catch Hook step
"""

import datetime
import os
import json
import urllib.request
import urllib.parse

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                Paragraph, Spacer, HRFlowable)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# ── Date range: always Mon–Sun of the current week ─────────────
today   = datetime.date.today()
monday  = today - datetime.timedelta(days=today.weekday())   # this Monday
week    = [monday + datetime.timedelta(days=i) for i in range(7)]
DAY_NAMES = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

OUTPUT = f"NYC_DR_Forecast_{monday.strftime('%Y-%m-%d')}.pdf"

# ── Fetch forecast from National Weather Service (weather.gov) ──
# NWS is the authoritative US government source — the same data
# underlying Weather.com — and requires no API key.
#
# Flow: points endpoint → forecast office grid → 7-day forecast periods
# NYC grid: OKX (Upton, NY) office, gridX=33, gridY=37
NWS_FORECAST_URL = "https://api.weather.gov/gridpoints/OKX/33,37/forecast"
NWS_HEADERS = {
    "User-Agent": "NYC-DR-Forecast/1.0 (demand-response-report; contact@example.com)",
    "Accept": "application/geo+json",
}

def nws_condition(short_forecast):
    """Normalise NWS short forecast text to a tidy condition label."""
    sf = short_forecast.lower()
    if "thunderstorm" in sf:            return "Thunderstorms"
    if "snow" in sf:                    return "Snow"
    if "rain" in sf and "chance" in sf: return "Chance of Rain"
    if "rain" in sf or "shower" in sf:  return "Rain Showers"
    if "drizzle" in sf:                 return "Drizzle"
    if "fog" in sf:                     return "Foggy"
    if "mostly sunny" in sf:            return "Mostly Sunny"
    if "partly sunny" in sf:            return "Partly Sunny"
    if "partly cloudy" in sf:           return "Partly Cloudy"
    if "mostly cloudy" in sf:           return "Mostly Cloudy"
    if "cloudy" in sf:                  return "Cloudy"
    if "sunny" in sf:                   return "Sunny"
    if "clear" in sf:                   return "Clear"
    return short_forecast.split(" and ")[0].title()

def fetch_weather():
    """
    Calls the NWS 7-day forecast endpoint for NYC and returns a list of
    (date_str, day_name, high_f, low_f, condition) tuples for Mon–Sun.

    NWS returns alternating day/night periods; we pair them to get
    each day's high (daytime period) and low (overnight period).
    """
    try:
        req  = urllib.request.Request(NWS_FORECAST_URL, headers=NWS_HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())

        periods = data["properties"]["periods"]

        # Build a dict keyed by date: {"high": X, "low": Y, "condition": Z}
        by_date = {}
        for p in periods:
            # startTime like "2026-05-11T06:00:00-04:00"
            dt   = datetime.date.fromisoformat(p["startTime"][:10])
            temp = p["temperature"]   # already in °F
            cond = nws_condition(p["shortForecast"])
            if p["isDaytime"]:
                by_date.setdefault(dt, {})["high"] = temp
                by_date.setdefault(dt, {})["condition"] = cond
            else:
                by_date.setdefault(dt, {})["low"] = temp

        results = []
        for i, d in enumerate(week):
            info = by_date.get(d, {})
            high = info.get("high", "N/A")
            low  = info.get("low",  "N/A")
            cond = info.get("condition", "—")
            results.append((d.strftime("%-b %-d"), DAY_NAMES[i], high, low, cond))

        print(f"NWS weather fetched successfully for {week[0]} – {week[-1]}.")
        return results

    except Exception as e:
        print(f"NWS weather fetch failed ({e}), using fallback placeholders.")
        return [
            (d.strftime("%-b %-d"), DAY_NAMES[i], "N/A", "N/A", "Unavailable")
            for i, d in enumerate(week)
        ]

# ── DR likelihood based on forecast high ───────────────────────
def dr_likelihood(high_f):
    """
    Returns a likelihood label based on the daily high temperature.
    Thresholds derived from historical NYISO Zone J / ConEd activation patterns.
      < 80°F  → Low       (no meaningful grid stress)
      80–87°F → Moderate  (elevated load, utility monitoring active)
      88–93°F → Elevated  (approaching ConEd CSRP threshold)
      94°F+   → High      (peak demand; SCR & CDR events very likely)
    """
    if not isinstance(high_f, int):
        return "Low"
    if high_f >= 94:   return "High"
    if high_f >= 88:   return "Elevated"
    if high_f >= 80:   return "Moderate"
    return "Low"

# ── Colour helpers ──────────────────────────────────────────────
DR_BG   = {"Low":"#D5F5E3","Moderate":"#FCF3CF","Elevated":"#FDEBD0","High":"#FDEDEC"}
DR_TEXT = {"Low":"#1A6B37","Moderate":"#7D5A00","Elevated":"#7D3A00","High":"#7D0000"}

def hex2color(h): return colors.HexColor(h)

# ── Build PDF ───────────────────────────────────────────────────
def build_pdf(days):
    doc = SimpleDocTemplate(
        OUTPUT,
        pagesize=letter,
        rightMargin=0.6*inch, leftMargin=0.6*inch,
        topMargin=0.5*inch,   bottomMargin=0.5*inch,
    )
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle("title", parent=styles["Title"],
        fontSize=17, leading=20, textColor=hex2color("#0D2B6B"),
        spaceAfter=2, alignment=TA_CENTER)
    subtitle_style = ParagraphStyle("subtitle", parent=styles["Normal"],
        fontSize=9, textColor=hex2color("#444444"),
        spaceAfter=4, alignment=TA_CENTER)
    section_style = ParagraphStyle("section", parent=styles["Heading2"],
        fontSize=10, textColor=colors.white,
        backColor=hex2color("#0D2B6B"),
        leading=14, spaceBefore=8, spaceAfter=4,
        leftIndent=6, alignment=TA_LEFT)
    note_style = ParagraphStyle("note", parent=styles["Normal"],
        fontSize=7.5, textColor=hex2color("#333333"), leading=10)
    footer_style = ParagraphStyle("footer", parent=styles["Normal"],
        fontSize=7, textColor=hex2color("#777777"),
        alignment=TA_CENTER, leading=9)

    LIGHT_HEADER = hex2color("#E8EEF7")
    ALT_ROW      = hex2color("#F5F8FF")
    WHITE        = colors.white

    story = []

    # Title
    week_label = f"{week[0].strftime('%B %-d')}–{week[-1].strftime('%-d, %Y')}"
    story.append(Paragraph("NYC Demand Response Forecast", title_style))
    story.append(Paragraph(
        f"Daily Temperature &amp; Grid Demand Response Likelihood &nbsp;|&nbsp; {week_label}",
        subtitle_style))
    story.append(Paragraph(
        "Programs: NYISO Special Case Resources (SCR) &nbsp;|&nbsp; ConEd Commercial Demand Response",
        subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5,
        color=hex2color("#0D2B6B"), spaceAfter=8))

    # ── Forecast table ──────────────────────────────────────────
    story.append(Paragraph("  Weekly Forecast &amp; Demand Response Outlook", section_style))
    story.append(Spacer(1, 4))

    col_widths = [0.82*inch, 0.92*inch, 0.72*inch, 0.72*inch,
                  1.15*inch, 1.38*inch, 1.38*inch]
    hdr = ["Date","Day","High °F","Low °F","Conditions",
           "NYISO SCR\nLikelihood","ConEd CDR\nLikelihood"]

    h_ps  = ParagraphStyle("th", fontSize=8, textColor=colors.white,
        alignment=TA_CENTER, leading=10)
    c_ps  = ParagraphStyle("td", fontSize=8.5, alignment=TA_CENTER, leading=11)
    co_ps = ParagraphStyle("cond",fontSize=8, alignment=TA_CENTER, leading=10,
        textColor=hex2color("#334466"))

    table_data = [[Paragraph(h, h_ps) for h in hdr]]

    for date, day, hi, lo, cond in days:
        scr   = dr_likelihood(hi)
        coned = dr_likelihood(hi)

        hi_col = (hex2color("#C0392B") if isinstance(hi,int) and hi >= 90 else
                  hex2color("#E67E22") if isinstance(hi,int) and hi >= 80 else
                  hex2color("#2471A3"))
        lo_col = (hex2color("#2471A3") if isinstance(lo,int) and lo < 50 else
                  hex2color("#1A7A4A"))

        hi_ps = ParagraphStyle("hi", fontSize=9, alignment=TA_CENTER,
            fontName="Helvetica-Bold", textColor=hi_col, leading=11)
        lo_ps = ParagraphStyle("lo", fontSize=9, alignment=TA_CENTER,
            fontName="Helvetica-Bold", textColor=lo_col, leading=11)
        scr_ps = ParagraphStyle("s", fontSize=8.5, alignment=TA_CENTER,
            fontName="Helvetica-Bold", textColor=hex2color(DR_TEXT[scr]), leading=11)
        con_ps = ParagraphStyle("c", fontSize=8.5, alignment=TA_CENTER,
            fontName="Helvetica-Bold", textColor=hex2color(DR_TEXT[coned]), leading=11)

        table_data.append([
            Paragraph(date,    c_ps),
            Paragraph(day,     c_ps),
            Paragraph(str(hi), hi_ps),
            Paragraph(str(lo), lo_ps),
            Paragraph(cond,    co_ps),
            Paragraph(scr,     scr_ps),
            Paragraph(coned,   con_ps),
        ])

    tbl = Table(table_data, colWidths=col_widths, repeatRows=1)
    ts_cmds = [
        ("BACKGROUND",    (0,0), (-1,0), hex2color("#0D2B6B")),
        ("GRID",          (0,0), (-1,-1), 0.4, hex2color("#CCCCCC")),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [WHITE, ALT_ROW]),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("RIGHTPADDING",  (0,0), (-1,-1), 4),
        ("LINEBELOW",     (0,0), (-1,0),  1.5, hex2color("#0D2B6B")),
    ]
    for i, (_, _, hi, _, _) in enumerate(days):
        row = i + 1
        scr = dr_likelihood(hi)
        for col in (5, 6):
            ts_cmds.append(("BACKGROUND", (col,row), (col,row),
                            hex2color(DR_BG[scr])))
    tbl.setStyle(TableStyle(ts_cmds))
    story.append(tbl)
    story.append(Spacer(1, 10))

    # ── Week-ahead outlook ──────────────────────────────────────
    story.append(Paragraph("  Week-Ahead Outlook", section_style))
    story.append(Spacer(1, 4))

    numeric_days = [(d,n,h,l,c) for d,n,h,l,c in days if isinstance(h, int)]
    if numeric_days:
        peak = max(numeric_days, key=lambda x: x[2])
        peak_date, peak_name, peak_hi = peak[0], peak[1], peak[2]
        all_low = all(dr_likelihood(h) == "Low" for _,_,h,_,_ in numeric_days)
        if peak_hi >= 88:
            risk_phrase = (f"<b>{peak_name}, {peak_date}</b> is the highest-risk day "
                           f"(forecast high: <b>{peak_hi}°F</b>) and should be treated as "
                           f"a probable DR event day — curtailment plans should be reviewed.")
        elif peak_hi >= 80:
            risk_phrase = (f"<b>{peak_name}, {peak_date}</b> is the warmest day of the period "
                           f"(forecast high: <b>{peak_hi}°F</b>) and carries the highest, "
                           f"though still moderate, DR likelihood — utility monitoring will be active.")
        else:
            risk_phrase = (f"<b>{peak_name}, {peak_date}</b> is the warmest day of the period "
                           f"(forecast high: <b>{peak_hi}°F</b>), though temperatures remain well "
                           f"below the 88–90°F+ threshold historically associated with DR activation "
                           f"in NYISO Zone J / ConEd territory.")
        if all_low:
            outlook_text = ("Demand response activity is <b>not expected</b> for either NYISO "
                            "Special Case Resources or ConEd Commercial Demand Response programs "
                            "this week. " + risk_phrase +
                            " No curtailment actions are required at this time.")
        else:
            outlook_text = ("Elevated grid conditions are forecast for portions of this week. "
                            + risk_phrase)
    else:
        outlook_text = ("Weather data was unavailable at generation time. "
                        "Please check the Open-Meteo API and re-run if needed.")

    out_ps = ParagraphStyle("out", parent=styles["Normal"],
        fontSize=9, textColor=hex2color("#1A1A2E"), leading=13,
        leftIndent=8, rightIndent=8)
    out_tbl = Table([[Paragraph(outlook_text, out_ps)]], colWidths=[7.15*inch])
    out_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,-1), hex2color("#EBF5FB")),
        ("BOX",           (0,0),(-1,-1), 1.2, hex2color("#2471A3")),
        ("TOPPADDING",    (0,0),(-1,-1), 8),
        ("BOTTOMPADDING", (0,0),(-1,-1), 8),
        ("LEFTPADDING",   (0,0),(-1,-1), 10),
        ("RIGHTPADDING",  (0,0),(-1,-1), 10),
    ]))
    story.append(out_tbl)
    story.append(Spacer(1, 10))

    # ── Legend ──────────────────────────────────────────────────
    story.append(Paragraph("  Demand Response Likelihood Legend", section_style))
    story.append(Spacer(1, 4))

    legend_items = [
        ("Low",      "#D5F5E3","#1A6B37",
         "Daily high &lt; 80°F. Grid load well within normal operating range. No DR events expected."),
        ("Moderate", "#FCF3CF","#7D5A00",
         "Daily high 80–87°F. Grid load elevated; utility monitoring active. DR event possible but unlikely."),
        ("Elevated", "#FDEBD0","#7D3A00",
         "Daily high 88–93°F. Approaching ConEd CSRP threshold. DR event probable; prepare curtailment plan."),
        ("High",     "#FDEDEC","#7D0000",
         "Daily high 94°F+. Peak demand conditions. NYISO SCR and ConEd CDR events very likely."),
    ]
    leg_data = []
    for label, bg, txt, desc in legend_items:
        lbl_ps  = ParagraphStyle("ll", fontSize=9, fontName="Helvetica-Bold",
            textColor=hex2color(txt), alignment=TA_CENTER, leading=11)
        desc_ps = ParagraphStyle("ld", fontSize=8,
            textColor=hex2color("#333333"), leading=10)
        leg_data.append([Paragraph(label, lbl_ps), Paragraph(desc, desc_ps)])

    leg_tbl = Table(leg_data, colWidths=[0.85*inch, 5.85*inch])
    leg_ts  = [
        ("GRID",          (0,0),(-1,-1), 0.4, hex2color("#BBBBBB")),
        ("VALIGN",        (0,0),(-1,-1), "MIDDLE"),
        ("TOPPADDING",    (0,0),(-1,-1), 5),
        ("BOTTOMPADDING", (0,0),(-1,-1), 5),
        ("LEFTPADDING",   (0,0),(-1,-1), 6),
        ("RIGHTPADDING",  (0,0),(-1,-1), 6),
    ]
    for i,(label,bg,_,_) in enumerate(legend_items):
        leg_ts.append(("BACKGROUND",(0,i),(0,i), hex2color(bg)))
        leg_ts.append(("BACKGROUND",(1,i),(1,i),
            hex2color("#FAFAFA") if i%2==0 else WHITE))
    leg_tbl.setStyle(TableStyle(leg_ts))
    story.append(leg_tbl)
    story.append(Spacer(1, 10))

    # ── Program reference ────────────────────────────────────────
    story.append(Paragraph("  Program Reference", section_style))
    story.append(Spacer(1, 5))

    prog_data = [
        [Paragraph("<b>NYISO Special Case Resources (SCR)</b>", note_style),
         Paragraph("<b>ConEd Commercial Demand Response (CDR)</b>", note_style)],
        [Paragraph(
            "An NYISO capacity program (May 1–Oct 31) that dispatches enrolled customers to "
            "reduce load during grid reliability events, typically triggered by extreme heat "
            "and unexpected demand spikes. Participants commit to reduce a pre-agreed kW amount "
            "upon day-ahead notice. Events are rare in May; the high-risk season is July–August "
            "when NYC peak loads approach system capacity. Activation requires NYISO-declared "
            "shortage conditions.", note_style),
         Paragraph(
            "Con Edison's suite of summer demand response programs, including the Commercial "
            "System Relief Program (CSRP) and Distribution Load Relief Program (DLRP), both "
            "active May 1–Sep 30. CSRP is activated when ConEd's day-ahead peak load forecast "
            "exceeds a zone-specific threshold. DLRP is a contingency program called during "
            "distribution network emergencies. In mid-May, temperatures in the 60s–70s°F keep "
            "ConEd zone loads well below peak thresholds, making CDR activations highly "
            "unlikely.", note_style)],
    ]
    prog_tbl = Table(prog_data, colWidths=[3.3*inch, 3.4*inch])
    prog_tbl.setStyle(TableStyle([
        ("GRID",          (0,0),(-1,-1), 0.4, hex2color("#BBBBBB")),
        ("BACKGROUND",    (0,0),(-1,0),  LIGHT_HEADER),
        ("VALIGN",        (0,0),(-1,-1), "TOP"),
        ("TOPPADDING",    (0,0),(-1,-1), 6),
        ("BOTTOMPADDING", (0,0),(-1,-1), 6),
        ("LEFTPADDING",   (0,0),(-1,-1), 6),
        ("RIGHTPADDING",  (0,0),(-1,-1), 6),
    ]))
    story.append(prog_tbl)
    story.append(Spacer(1, 8))

    # ── Footer ───────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.7,
        color=hex2color("#AAAAAA"), spaceAfter=4))
    story.append(Paragraph(
        f"Weather data sourced from National Weather Service (weather.gov). "
        "NYISO SCR program details from NYISO.com/demand-response. "
        "ConEd CDR program details from coned.com. "
        "Demand response likelihood is an analytical estimate based on historical activation "
        "thresholds and is not an official NYISO or ConEd advisory. "
        f"Generated {datetime.date.today().strftime('%B %-d, %Y')}.",
        footer_style))

    doc.build(story)
    print(f"PDF saved: {OUTPUT}")
    return OUTPUT

# ── Send to Zapier ──────────────────────────────────────────────
def send_to_zapier(pdf_path):
    webhook_url = os.environ.get("ZAPIER_WEBHOOK_URL", "")
    if not webhook_url:
        print("ZAPIER_WEBHOOK_URL not set — skipping webhook.")
        return

    week_label = f"{week[0].strftime('%B %-d')}–{week[-1].strftime('%-d, %Y')}"
    payload = json.dumps({
        "filename":    pdf_path,
        "week":        week_label,
        "generated":   datetime.date.today().isoformat(),
        "title":       f"NYC DR Forecast — {week_label}",
        "message":     (
            f"📊 **NYC Demand Response Forecast — {week_label}**\n"
            "The weekly PDF has been generated and is attached below. "
            "Check the Week-Ahead Outlook section for the highest-risk day."
        ),
    }).encode()

    req = urllib.request.Request(
        webhook_url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            print(f"Zapier notified: HTTP {resp.status}")
    except Exception as e:
        print(f"Zapier webhook failed: {e}")

# ── Main ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"Fetching weather for {week[0]} – {week[-1]} …")
    days    = fetch_weather()
    pdf     = build_pdf(days)
    send_to_zapier(pdf)
